var searchData=
[
  ['mainvboxlayout',['mainVBoxLayout',['../classmainWidget.html#acde0d49995cc7e5bfdfd5f17d809b7ca',1,'mainWidget']]],
  ['mainwidget',['mainWidget',['../classmainWidget.html',1,'mainWidget'],['../classmainWidget.html#ad73a469a876f7642f125c2e114fde3b6',1,'mainWidget::mainWidget()']]],
  ['mainwidget_2ecpp',['mainWidget.cpp',['../mainWidget_8cpp.html',1,'']]],
  ['mainwidget_2eh',['mainWidget.h',['../mainWidget_8h.html',1,'']]]
];
