var searchData=
[
  ['previouscores_2ecpp',['previouscores.cpp',['../previouscores_8cpp.html',1,'']]],
  ['previouscores_2eh',['previouscores.h',['../previouscores_8h.html',1,'']]]
];
