var searchData=
[
  ['collectable',['collectable',['../classcollectable.html',1,'']]]
];
