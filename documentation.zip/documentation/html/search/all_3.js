var searchData=
[
  ['labelstyle',['labelStyle',['../classmainWidget.html#a9a968f9369645f35294a70efedb6db03',1,'mainWidget']]]
];
