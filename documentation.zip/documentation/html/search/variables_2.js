var searchData=
[
  ['mainvboxlayout',['mainVBoxLayout',['../classmainWidget.html#acde0d49995cc7e5bfdfd5f17d809b7ca',1,'mainWidget']]]
];
