var searchData=
[
  ['playasguest',['playAsGuest',['../classmainWidget.html#afc358112a27702edf74ff89cc485a8d1',1,'mainWidget']]],
  ['playgame1slot',['playGame1slot',['../classgameMenu.html#a9f3538c69643622caf718099e9b0ac6b',1,'gameMenu']]],
  ['playgame2slot',['playGame2slot',['../classgameMenu.html#a8d609113b5a0ee6490ed210d2abe0ef3',1,'gameMenu']]]
];
