var searchData=
[
  ['returntomenu',['returnToMenu',['../classgame1scene.html#a71ccc3681845bdebd3f6d34b61a3e1fe',1,'game1scene::returnToMenu()'],['../classgameMenu.html#a8d5eef5807e8267751a7a97f2db84d7c',1,'gameMenu::returnToMenu()'],['../classpreviouscores.html#ae9abef14aa5eb45f9adb5c456c912da6',1,'previouscores::returnToMenu()'],['../classsignUpPage.html#ad1c0549d42c6277c673f9e0134643639',1,'signUpPage::returnToMenu()']]]
];
