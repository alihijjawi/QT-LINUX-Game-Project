var searchData=
[
  ['mainwidget_2ecpp',['mainWidget.cpp',['../mainWidget_8cpp.html',1,'']]],
  ['mainwidget_2eh',['mainWidget.h',['../mainWidget_8h.html',1,'']]]
];
