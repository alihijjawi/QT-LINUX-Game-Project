var searchData=
[
  ['mainwidget',['mainWidget',['../classmainWidget.html#ad73a469a876f7642f125c2e114fde3b6',1,'mainWidget']]]
];
