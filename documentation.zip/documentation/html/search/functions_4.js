var searchData=
[
  ['playasguest',['playAsGuest',['../classmainWidget.html#afc358112a27702edf74ff89cc485a8d1',1,'mainWidget']]]
];
