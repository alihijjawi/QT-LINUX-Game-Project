var searchData=
[
  ['getgamerules',['getGameRules',['../classgame2scene.html#adf7d8c5401c60cf2c2a18141413371d6',1,'game2scene']]],
  ['getglobalhighscore',['getGlobalHighscore',['../classgame2scene.html#a48e7f43f5c7e9ebe208d571bcc685f37',1,'game2scene']]]
];
