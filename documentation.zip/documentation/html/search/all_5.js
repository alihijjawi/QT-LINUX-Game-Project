var searchData=
[
  ['opensignup',['openSignUp',['../classmainWidget.html#a87cdb619caf0793c49a656b8e8f18286',1,'mainWidget']]]
];
