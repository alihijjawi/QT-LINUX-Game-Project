var searchData=
[
  ['mainwidget',['mainWidget',['../classmainWidget.html',1,'']]]
];
