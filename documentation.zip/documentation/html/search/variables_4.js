var searchData=
[
  ['signinbutton',['SignInButton',['../classmainWidget.html#a62b73d60926f49dea05386f1ccd135f2',1,'mainWidget']]],
  ['signupbutton',['SignUpButton',['../classmainWidget.html#a28fd48ab6d6920c9f9fe1a789c7ee1ff',1,'mainWidget']]]
];
