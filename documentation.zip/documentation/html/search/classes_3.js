var searchData=
[
  ['previouscores',['previouscores',['../classpreviouscores.html',1,'']]]
];
