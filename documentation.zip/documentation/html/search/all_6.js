var searchData=
[
  ['project_20group_201',['Project Group 1',['../index.html',1,'']]],
  ['playasguest',['playAsGuest',['../classmainWidget.html#afc358112a27702edf74ff89cc485a8d1',1,'mainWidget']]],
  ['playgame1slot',['playGame1slot',['../classgameMenu.html#a9f3538c69643622caf718099e9b0ac6b',1,'gameMenu']]],
  ['playgame2slot',['playGame2slot',['../classgameMenu.html#a8d609113b5a0ee6490ed210d2abe0ef3',1,'gameMenu']]],
  ['previouscores',['previouscores',['../classpreviouscores.html',1,'']]],
  ['previouscores_2ecpp',['previouscores.cpp',['../previouscores_8cpp.html',1,'']]],
  ['previouscores_2eh',['previouscores.h',['../previouscores_8h.html',1,'']]]
];
